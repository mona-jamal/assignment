#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define ARRAY_SIZE 10000 // we change this value based on the array size we want to test
#define NUM_THREADS 32   // we change this value based on the number of threads we want to test

// Determine the size of L1 cache on the computer
#define CACHE_LINE_SIZE 64

// Define a struct to hold private count and dummy array
typedef struct
{
    int private_count;
    char padding[CACHE_LINE_SIZE - sizeof(int)]; // Dummy array to fill the cache line
} PrivateData;

int *array;
int length = ARRAY_SIZE;
PrivateData *private_counts;

void *count1s(void *thread_id)
{
    long tid = (long)thread_id;
    int local_count = 0;

    for (int i = tid; i < length; i += NUM_THREADS)
    {
        if (array[i] == 1)
        {
            local_count++;
        }
    }

    // Store the local count in the private_counts array
    private_counts[tid].private_count = local_count;

    pthread_exit(NULL);
}

int main()
{
    array = (int *)malloc(length * sizeof(int));
    private_counts = (PrivateData *)malloc(NUM_THREADS * sizeof(PrivateData));

    if (array == NULL || private_counts == NULL)
    {
        perror("Error allocating memory for array or private counts");
        exit(EXIT_FAILURE);
    }

    // Set the seed for the random number generator
    srand((unsigned int)time(NULL));

    // Generate random integers between 0 and 5 (inclusive)
    for (int i = 0; i < length; i++)
    {
        array[i] = rand() % 6;
    }

    // Create an array of threads
    pthread_t threads[NUM_THREADS];
    int rc;
    long t;

    struct timeval start, end;

    gettimeofday(&start, NULL);

    // Create threads
    for (t = 0; t < NUM_THREADS; t++)
    {
        rc = pthread_create(&threads[t], NULL, count1s, (void *)t);
        if (rc)
        {
            fprintf(stderr, "ERROR: return code from pthread_create() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    // Join threads
    for (t = 0; t < NUM_THREADS; t++)
    {
        rc = pthread_join(threads[t], NULL);
        if (rc)
        {
            fprintf(stderr, "ERROR: return code from pthread_join() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    gettimeofday(&end, NULL);

    // Sum up the private counts to obtain the total count
    int total_count = 0;
    for (int i = 0; i < NUM_THREADS; i++)
    {
        total_count += private_counts[i].private_count;
    }

    // Calculate the runtime in seconds
    double runtime = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec) / 1000000;

    printf("Total count of ones: %d\n", total_count);
    printf("Runtime: %f seconds\n", runtime);

    // Clean up
    free(array);
    free(private_counts);

    return 0;
}
