#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define ARRAY_SIZE 10000
#define NUM_THREADS 32

void *count1s(void *thread_id);

int *array;
int length = ARRAY_SIZE;
int *thread_counts;
int rightCount = 0;

int main()
{
    srand((unsigned int)time(NULL));

    printf("| Array Size | Num Threads | Runtime (s) |\n");
    printf("|------------|-------------|--------------|\n");

    for (int k = 0; k < 10; k++)
    {
        rightCount = 0;
        array = (int *)malloc(length * sizeof(int));
        thread_counts = (int *)malloc(NUM_THREADS * sizeof(int));

        if (array == NULL || thread_counts == NULL)
        {
            perror("Error allocating memory for array or thread counts");
            exit(EXIT_FAILURE);
        }

        for (int i = 0; i < length; i++)
        {
            array[i] = rand() % 6;
        }
        // loop over the array to count the correct number of generated ones
        for (int i = 0; i < length; i++)
        {
            if (array[i] == 1)
            {
                rightCount++;
            }
        }

        pthread_t threads[NUM_THREADS];
        int rc;
        long t;

        struct timeval start, end;

        gettimeofday(&start, NULL);

        for (t = 0; t < NUM_THREADS; t++)
        {
            rc = pthread_create(&threads[t], NULL, count1s, (void *)t);
            if (rc)
            {
                fprintf(stderr, "ERROR: return code from pthread_create() is %d\n", rc);
                exit(EXIT_FAILURE);
            }
        }

        for (t = 0; t < NUM_THREADS; t++)
        {
            rc = pthread_join(threads[t], NULL);
            if (rc)
            {
                fprintf(stderr, "ERROR: return code from pthread_join() is %d\n", rc);
                exit(EXIT_FAILURE);
            }
        }

        gettimeofday(&end, NULL);

        double runtime = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec) / 1000000;

        int total_count = 0;
        for (t = 0; t < NUM_THREADS; t++)
        {
            total_count += thread_counts[t];
        }

        printf("| %-10d | %-11d | %-12.6f |\n", length, NUM_THREADS, runtime);

        free(array);
        free(thread_counts);
    }

    return 0;
}

void *count1s(void *thread_id)
{
    long tid = (long)thread_id;
    thread_counts[tid] = 0;

    for (int i = tid; i < length; i += NUM_THREADS)
    {
        if (array[i] == 1)
        {
            thread_counts[tid]++;
        }
    }

    pthread_exit(NULL);
}
