#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define ARRAY_SIZE 100000 // Change this value based on the array size we want to test
#define NUM_THREADS 32    // Change this value based on the number of threads we want to test

int *array;
int length = ARRAY_SIZE;
int *private_counts;

void *count1s(void *thread_id)
{
    long tid = (long)thread_id;
    int local_count = 0;

    for (int i = tid; i < length; i += NUM_THREADS)
    {
        if (array[i] == 1)
        {
            local_count++;
        }
    }

    // Store the local count in the private_counts array
    private_counts[tid] = local_count;

    pthread_exit(NULL);
}

int main()
{
    array = (int *)malloc(length * sizeof(int));
    private_counts = (int *)malloc(NUM_THREADS * sizeof(int));

    if (array == NULL || private_counts == NULL)
    {
        perror("Error allocating memory for array or private counts");
        exit(EXIT_FAILURE);
    }

    // Set the seed for the random number generator
    srand((unsigned int)time(NULL));

    // Generate random integers between 0 and 5 (inclusive)
    for (int i = 0; i < length; i++)
    {
        array[i] = rand() % 6;
    }
    // loop over the array to count the correct number of generated ones
    for (int i = 0; i < length; i++)
    {
        if (array[i] == 1)
        {
            rightCount++;
        }
    }

    // Create an array of threads
    pthread_t threads[NUM_THREADS];
    int rc;
    long t;

    struct timeval start, end;

    gettimeofday(&start, NULL);

    // Create threads
    for (t = 0; t < NUM_THREADS; t++)
    {
        rc = pthread_create(&threads[t], NULL, count1s, (void *)t);
        if (rc)
        {
            fprintf(stderr, "ERROR: return code from pthread_create() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    // Join threads
    for (t = 0; t < NUM_THREADS; t++)
    {
        rc = pthread_join(threads[t], NULL);
        if (rc)
        {
            fprintf(stderr, "ERROR: return code from pthread_join() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    gettimeofday(&end, NULL);

    // Sum up the private counts to obtain the total count
    int total_count = 0;
    for (int i = 0; i < NUM_THREADS; i++)
    {
        total_count += private_counts[i];
    }

    // Calculate the runtime in seconds
    double runtime = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec) / 1000000;

    printf("Total count of ones: %d\n", total_count);
    printf("Runtime: %f seconds\n", runtime);

    // Clean up
    free(array);
    free(private_counts);

    return 0;
}
